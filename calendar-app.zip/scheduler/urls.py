from django.urls import path
from .views import index, send_sms, authorize_google, oauth2callback, views, handle_call, ivr_menu, \
    voicemail, sms_handler, answer_call, check_credentials

urlpatterns = [
    path('', index, name='index'),  # Home page
    path('send_sms/', send_sms, name='send_sms'),  # SMS sending endpoint
    path('authorize/', authorize_google, name='authorize_google'),  # Google auth endpoint
    path('oauth2callback/', oauth2callback, name='oauth2callback'),  # Callback for Google auth
    path('voice/', handle_call, name='handle_call'),
    path('ivr-menu/', ivr_menu, name='ivr_menu'),
    path('voicemail/', voicemail, name='voicemail'),
    path('sms/', sms_handler, name='sms_handler'),
    path('answer-call/', answer_call, name='answer_call'),
    path('check-credentials/', check_credentials, name='check-credentials'),
    #path('admin/', site.urls),
    #path('', include('scheduler.urls')),
    # Add more paths as needed
]

