from django.db import models

# Create your models here.
# scheduler/models.py
from django.db import models


from django.db import models

class GoogleCredentials(models.Model):
    token = models.TextField()
    refresh_token = models.TextField()
    token_uri = models.TextField()
    client_id = models.TextField()
    client_secret = models.TextField()
    scopes = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Appointment(models.Model):
    user_phone = models.CharField(max_length=15)
    appointment_time = models.DateTimeField()
    description = models.TextField()
