from django.shortcuts import render
from google_auth_oauthlib.flow import Flow
from django.shortcuts import redirect
from django.conf import settings  # Import settings to access GOOGLE_CREDENTIALS_PATH
import os
from django.http import HttpResponse
from twilio.twiml.voice_response import VoiceResponse
from django.http import HttpResponse
from twilio.twiml.messaging_response import MessagingResponse
from django.views.decorators.csrf import csrf_exempt
import logging
from datetime import datetime, timedelta, timezone
from .models import GoogleCredentials
from django.shortcuts import render
from .google_calendar import authenticate_google_calendar

logger = logging.getLogger(__name__)
from functools import wraps
from twilio.request_validator import RequestValidator
from django.http import HttpResponseForbidden
import os

from functools import wraps
from twilio.request_validator import RequestValidator
from django.conf import settings
from django.http import HttpResponseForbidden

# Create your views here.
# scheduler/views.py
from django.shortcuts import render, redirect
from twilio.rest import Client
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from openai import OpenAI
import json
from datetime import datetime, timedelta
import dateparser
from django.conf import settings
from twilio.twiml.messaging_response import MessagingResponse
import os

# Allow HTTP connections for OAuth during local development
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'


def index(request):
    return render(request, 'index.html')


from django.views.decorators.csrf import csrf_exempt
from twilio.twiml.messaging_response import MessagingResponse
from django.http import HttpResponse

from django.shortcuts import render, redirect
from django.http import HttpResponse
from twilio.rest import Client
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
import os
import re
from datetime import datetime, timedelta

import os
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle

SCOPES = ['https://www.googleapis.com/auth/calendar']

# Allow HTTP connections for OAuth during local development
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

"""@csrf_exempt
def authenticate_google_calendar():
    creds = None
    # Check if token.pickle file exists to load saved credentials
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    # If there are no valid credentials, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'client_secret_815352087339-crqnec2qrkng2d5938711selgva9brfs.apps'
                '.googleusercontent.com-3.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds"""


@csrf_exempt
def index(request):
    print("lol")
    return render(request, 'index.html')


@csrf_exempt
def answer_call(request):
    response = VoiceResponse()
    response.say('Hello! You have reached the Django and Twilio voice application.', voice='alice')
    return HttpResponse(str(response), content_type='text/xml')


@csrf_exempt
def send_sms(request):
    if request.method == 'POST':
        message_body = request.POST['message']
        client = Client('TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN')
        client.messages.create(
            body=message_body,
            from_='YOUR_TWILIO_NUMBER',
            to='RECIPIENT_PHONE_NUMBER'
        )
        return redirect('index')


def validate_twilio_request(f):
    @wraps(f)
    def decorated_function(request, *args, **kwargs):
        validator = RequestValidator(os.environ.get('TWILIO_AUTH_TOKEN'))
        request_valid = validator.validate(
            request.build_absolute_uri(),
            request.POST,
            request.META.get('HTTP_X_TWILIO_SIGNATURE', '')
        )
        if request_valid:
            return f(request, *args, **kwargs)
        else:
            return HttpResponseForbidden()

    return decorated_function


@csrf_exempt
def parse_input(message):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": """
                Parse into JSON with type distinction:
                For events (like "schedule meeting 2pm"):
                {
                    "type": "event",
                    "title": "name",
                    "start_time": "time"
                }
                For tasks (like "create task walk today"):
                {
                    "type": "task",
                    "title": "name",
                    "due_date": "date"
                }
                """},
                {"role": "user", "content": message}
            ],
            response_format={"type": "json_object"}
        )

        info = json.loads(response.choices[0].message.content)
        if info.get('start_time'):
            info['start_time'] = dateparser.parse(info['start_time'])
        if info.get('due_date'):
            info['due_date'] = dateparser.parse(info['due_date'])
        return info
    except Exception as e:
        print(f"Error parsing input: {str(e)}")
        return None


def create_task(service, task_details):
    try:
        tasklist = service.tasklists().list().execute()
        tasklist_id = tasklist['items'][0]['id']

        task = {
            'title': task_details['title'],
            'notes': task_details.get('description', ''),
            'status': 'needsAction'
        }

        if task_details.get('due_date'):
            task['due'] = task_details['due_date'].isoformat() + 'Z'

        result = service.tasks().insert(tasklist=tasklist_id, body=task).execute()
        return result
    except Exception as e:
        print(f"Error creating task: {str(e)}")
        return None


def modify_task(service, task_id, changes):
    try:
        tasklist = service.tasklists().list().execute()
        tasklist_id = tasklist['items'][0]['id']

        task = service.tasks().get(tasklist=tasklist_id, task=task_id).execute()

        if 'new_title' in changes:
            task['title'] = changes['new_title']
        if 'new_due_date' in changes:
            task['due'] = changes['new_due_date'].isoformat()

        result = service.tasks().update(tasklist=tasklist_id, task=task_id, body=task).execute()
        return result
    except Exception as e:
        print(f"Error modifying task: {str(e)}")
        return None


def find_task(service, task_title):
    try:
        tasklist = service.tasklists().list().execute()
        tasklist_id = tasklist['items'][0]['id']

        tasks = service.tasks().list(tasklist=tasklist_id).execute()

        for task in tasks.get('items', []):
            if task_title.lower() in task['title'].lower():
                return task
        return None
    except Exception as e:
        print(f"Error finding task: {str(e)}")
        return None
# Also add logging to the sms_handler to see the parsed details
@csrf_exempt
def sms_handler(request):
    if request.method == 'POST':
        incoming_msg = request.POST.get('Body', '').lower()
        response = MessagingResponse()

        try:
            parsed_info = parse_input(incoming_msg)
            if not parsed_info:
                response.message("Could not understand request")
                return HttpResponse(str(response), content_type='application/xml')

            creds_db = GoogleCredentials.objects.first()
            if not creds_db:
                response.message("Please authenticate first")
                return HttpResponse(str(response), content_type='application/xml')

            credentials = Credentials(
                token=creds_db.token,
                refresh_token=creds_db.refresh_token,
                token_uri=creds_db.token_uri,
                client_id=creds_db.client_id,
                client_secret=creds_db.client_secret,
                scopes=creds_db.scopes.split(',')
            )

            if parsed_info['type'] == 'task':
                tasks_service = build('tasks', 'v1', credentials=credentials)
                task = create_task(tasks_service, parsed_info)
                if task:
                    response.message("Task created successfully!")
                else:
                    response.message("Error creating task")
            else:  # event
                if not parsed_info.get('start_time'):
                    response.message("Please specify a time for the appointment")
                    return HttpResponse(str(response), content_type='application/xml')

                calendar_service = build('calendar', 'v3', credentials=credentials)
                event = {
                    'summary': parsed_info['title'],
                    'start': {
                        'dateTime': parsed_info['start_time'].isoformat(),
                        'timeZone': 'America/New_York',
                    },
                    'end': {
                        'dateTime': (parsed_info['start_time'] + timedelta(hours=1)).isoformat(),
                        'timeZone': 'America/New_York',
                    }
                }
                created_event = calendar_service.events().insert(calendarId='primary', body=event).execute()
                response.message(f"Appointment created for {parsed_info['start_time'].strftime('%B %d at %I:%M %p')}")

        except Exception as e:
            print(f"Error: {str(e)}")
            response.message("Sorry, something went wrong")

        return HttpResponse(str(response), content_type='application/xml')
    return HttpResponse("Method not allowed", status=405)

@csrf_exempt  # Disable CSRF protection for this view
def handle_call(request):
    response = VoiceResponse()
    response.say('Hello! You have reached the Django and Twilio voice application.', voice='alice')
    return HttpResponse(str(response), content_type='text/xml')


# Initialize OpenAI client (you'll need to set your API key)
client = OpenAI(api_key=settings.OPENAI_API_KEY)  # Set your API key in environment variables

@csrf_exempt  # Disable CSRF protection for this view
def parse_event_details(message):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": """
                Parse the message and return JSON for a new calendar event:
                {
                    "summary": "event name with attendees",
                    "start_time": "parsed date and time",
                    "duration": "duration in hours",
                    "location": "location or Virtual"
                }
                """},
                {"role": "user", "content": message}
            ],
            response_format={"type": "json_object"}
        )

        event_info = json.loads(response.choices[0].message.content)

        # Parse the datetime
        event_time = dateparser.parse(event_info['start_time'])
        duration = 1  # Default 1 hour

        return {
            'summary': event_info['summary'],
            'start_time': event_time.isoformat(),
            'end_time': (event_time + timedelta(hours=duration)).isoformat(),
            'location': event_info.get('location', 'Virtual Meeting')
        }
    except Exception as e:
        print(f"Error in parse_event_details: {str(e)}")
        return None

def parse_modification_details(message):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": """
                Parse the message and return JSON in this format:
                {
                    "event_identifier": "event title",
                    "original_time": "time to find event at",
                    "new_time": "time to move event to"
                }
                """},
                {"role": "user", "content": message}
            ],
            response_format={"type": "json_object"}
        )

        info = json.loads(response.choices[0].message.content)

        # Parse times
        original_time = dateparser.parse(info['original_time'])
        new_time = dateparser.parse(info['new_time'])

        return {
            'event_identifier': info['event_identifier'],
            'original_time': original_time,
            'changes': {
                'new_start_time': new_time.isoformat(),
                'new_end_time': (new_time + timedelta(hours=1)).isoformat()
            }
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return None

def find_event(service, event_identifier, target_time=None):
    try:
        now = datetime.now(timezone.utc)
        time_min = now.isoformat()
        time_max = (now + timedelta(days=7)).isoformat()

        events_result = service.events().list(
            calendarId='primary',
            timeMin=time_min,
            timeMax=time_max,
            singleEvents=True,
            orderBy='startTime'
        ).execute()

        events = events_result.get('items', [])
        matching_events = []

        for event in events:
            if event_identifier.lower() in event.get('summary', '').lower():
                # If time was specified, check if event starts at that time
                if target_time:
                    event_start = datetime.fromisoformat(event['start']['dateTime'])
                    if event_start.hour == target_time.hour:
                        matching_events.append(event)
                else:
                    matching_events.append(event)

        return matching_events[0] if matching_events else None

    except Exception as e:
        print(f"Error finding event: {str(e)}")
        return None


def modify_event(service, event_id, changes):
    """Modify an existing calendar event."""
    try:
        # First get the existing event
        event = service.events().get(calendarId='primary', eventId=event_id).execute()

        # Update the event with new details
        if 'new_title' in changes:
            event['summary'] = changes['new_title']

        if 'new_start_time' in changes:
            event['start']['dateTime'] = changes['new_start_time']
            event['end']['dateTime'] = changes['new_end_time']

        if 'new_location' in changes:
            event['location'] = changes['new_location']

        # Update the event
        updated_event = service.events().update(
            calendarId='primary',
            eventId=event_id,
            body=event
        ).execute()

        return updated_event
    except Exception as e:
        print(f"Error modifying event: {str(e)}")
        return None

@csrf_exempt
def create_event_in_calendar(event_details, credentials):
    service = build('calendar', 'v3', credentials=credentials)

    event = {
        'summary': event_details['summary'],
        'start': {
            'dateTime': event_details['start_time'],
            'timeZone': 'America/New_York',
        },
        'end': {
            'dateTime': event_details['end_time'],
            'timeZone': 'America/New_York',
        },
    }

    service.events().insert(calendarId='primary', body=event).execute()


@csrf_exempt
def authorize_google(request):
    flow = Flow.from_client_secrets_file(
        settings.GOOGLE_CREDENTIALS_PATH,
        scopes=['https://www.googleapis.com/auth/calendar',
                'https://www.googleapis.com/auth/tasks'],
        redirect_uri=settings.OAUTH2_REDIRECT_URI
    )
    # Add access_type='offline' and prompt='consent' to force refresh token
    authorization_url, state = flow.authorization_url(
        access_type='offline',
        prompt='consent',  # Force consent screen to get new refresh token
        include_granted_scopes='true'
    )
    request.session['state'] = state
    return redirect(authorization_url)


@csrf_exempt
def oauth2callback(request):
    try:
        flow = Flow.from_client_secrets_file(
            settings.GOOGLE_CREDENTIALS_PATH,
            scopes=['https://www.googleapis.com/auth/calendar',
                    'https://www.googleapis.com/auth/tasks'],
            redirect_uri=settings.OAUTH2_REDIRECT_URI
        )

        authorization_response = request.build_absolute_uri()
        flow.fetch_token(authorization_response=authorization_response)
        credentials = flow.credentials

        # Clear existing credentials and save new ones
        GoogleCredentials.objects.all().delete()
        GoogleCredentials.objects.create(
            token=credentials.token,
            refresh_token=credentials.refresh_token or '',
            token_uri=credentials.token_uri or '',
            client_id=credentials.client_id or '',
            client_secret=credentials.client_secret or '',
            scopes=','.join(credentials.scopes) if credentials.scopes else ''
        )

        return HttpResponse('Successfully connected to Google Calendar and Tasks!')
    except Exception as e:
        print(f"Error in oauth2callback: {str(e)}")
        return HttpResponse(f'Error in oauth2callback: {str(e)}')


@csrf_exempt
def credentials_to_dict(credentials):
    return {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes,
    }


@csrf_exempt
def views(request):
    return None


@csrf_exempt
def ivr_menu(request):
    response = VoiceResponse()
    with response.gather(num_digits=1, action='/handle-key', method='POST') as gather:
        gather.say('For sales, press 1. For support, press 2.')
    return HttpResponse(str(response), content_type='text/xml')


@csrf_exempt
def check_credentials(request):
    from .models import GoogleCredentials
    creds = GoogleCredentials.objects.all()
    if creds.exists():
        cred = creds.first()
        return HttpResponse(
            f"Number of credential records: {creds.count()}\n"
            f"First credential ID: {cred.id}\n"
            f"Has token: {'Yes' if cred.token else 'No'}\n"
            f"Has refresh_token: {'Yes' if cred.refresh_token else 'No'}"
        )
    else:
        return HttpResponse("No credentials found in database")


@csrf_exempt
def voicemail(request):
    response = VoiceResponse()
    response.say('Please leave a message after the beep.')
    response.record(transcribe=True, transcribe_callback='/handle-transcription')
    return HttpResponse(str(response), content_type='text/xml')


@csrf_exempt
def check_session(request):
    credentials = request.session.get('credentials', 'No credentials found')
    return HttpResponse(f"Session contents: {credentials}")
